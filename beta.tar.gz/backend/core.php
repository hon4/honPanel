<?php
error_reporting(E_ALL^E_NOTICE);

require_once("backend/config.php");

function loginchk(){
	GLOBAL $CONF;
	if(!$_COOKIE['uid']||!$_COOKIE['pass']){
		header("Location: login.php");
	}else{
		if($_COOKIE['pass']!=sha1($CONF['USERS'][(int)$_COOKIE['uid']]['password'])){
			header("Location: login.php");
		}
	}
}
function dbconn(){
	GLOBAL $MYSQL;
	@mysql_connect($MYSQL['HOST'],$MYSQL['USER'],$MYSQL['PASS']) or die("MySQL Connection failed.");
	@mysql_select_db($MYSQL['NAME']) or die("Unable to select MySQL database.");
}
function sql_query($q){
	return @mysql_query($q);
}
function sqlesc($i){
	if(is_numeric($i)){
		return $i;
	}else{
		return '"'.mysql_real_escape_string($i).'"';
	}
}
function logoutcookie(){
	setcookie("uid",NULL,-1,"/");
	setcookie("pass",NULL,-1,"/");
}
function logincookie($uid,$pass,$expires=0x7fffffff){
	setcookie("uid",$uid,$expires,"/");
	setcookie("pass",sha1($pass),$expires,"/");
}

function stdhead(){
	require_once("themes/default/header.php");
}
function stdfoot(){
	require_once("themes/default/footer.php");
}
?>