<?php

$CONF['USERS'][1]['username']="root";
$CONF['USERS'][1]['password']="root";

$MYSQL['HOST']="localhost";
$MYSQL['USER']="root";
$MYSQL['PASS']="root";
$MYSQL['NAME']="honPanel";
?>