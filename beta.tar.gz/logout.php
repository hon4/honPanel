<?php
require_once("backend/core.php");
logoutcookie();
header("Location: index.php");
?>