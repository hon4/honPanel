<?php
require_once("backend/core.php");

if($_POST['username']&&$_POST['password']){
	if($CONF['USERS'][$_POST['username']]['password']==$_POST['password']){
		logincookie($_POST['username'],$_POST['password']);
		header("Location: index.php");
		die();
	}else{
		$message="Login failed.";
	}
}
logoutcookie();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<title>honPanel</title>
		<link rel="stylesheet" href="login.css"/>
		<link rel="icon" href="favicon.ico"/>
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	</head>
	<body>
	<?=($message?"<div id='error'>$message</div>":'')?>
	<div id="content">
		<div id="logo"></div>
		<form method="post">
			Username:
			<input type="text" name="username"/>
			Password:
			<input type="password" name="password"/>
			<center><input type="submit" value="Login"/></center>
			<p align="center"><a href="#">Forgot Password</a></p>
		</form>
	</div>
	</body>
</html>