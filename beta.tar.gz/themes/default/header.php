<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<title>honPanel</title>
		<link rel="stylesheet" href="themes/default/main.css"/>
		<link rel="icon" href="favicon.ico"/>
	</head>
	<body>
		<table id="pagetbl">
		<tr><td id="header"></td></tr>
		<tr>
		<td id="navcol">
			<ul class="nav">
				<li><a href="index.php" <?=(basename($_SERVER['PHP_SELF'])=="index.php"?'class="current"':'')?>>Home</a></li>
				<li><a href="sites.php">Website</a></li>
				<li><a href="ftp.php">FTP</a></li>
				<li><a href="db.php">Databases</a></li>
				<li><a href="files.php">Files</a></li>
				<li><a href="store.php" <?=(basename($_SERVER['PHP_SELF'])=="store.php"?'class="current"':'')?>>Store</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
			</td>
			<td id="mainpg">