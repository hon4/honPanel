<?php
require_once("backend/core.php");
loginchk();
dbconn();

stdhead();
?>
<form method="get">
<div id="block">Search: <input type="text" name="search"/> &nbsp; <input type="submit" value="Search"/></div>
</form><br/>
<table class="coltable" width="100%">
	<tr class="colhead"><td>Name</td></tr>
<?php
if($_GET['search'])
	$where = "WHERE name LIKE ".sqlesc("%$_GET[search]%");

$res=sql_query("SELECT * FROM store $where LIMIT 5");
while($row=mysql_fetch_assoc($res)){
	echo "<tr class='row1'><td><a href='storeitem.php?id=$row[id]'>$row[name]</a></td></tr>";
}
?>
</table>
<?php
stdfoot();
?>