<?php
require_once("backend/core.php");
loginchk();

stdhead();

stdfoot();
?>